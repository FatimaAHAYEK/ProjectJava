package com.product;

public class produit {
    private Long id ;

    private String nom ;

    private String prix ;




    public produit(long aLong, String string, String resultSetString) {
    }

    public produit(Long id_produit, String nom, String prix ) {
        this.id = id;
        this.nom = nom;
        this.prix = prix;

    }

    public Long getId_produit() {
        return id;
    }

    public void setId_produit(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }



    @Override
    public String toString() {
        return "produit{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prix='" + prix + '\'' +

                '}';
    }
}
