package com.product;

import com.Credite.Credit;
import com.exemple.model.BaseDAO;

import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
public class produitDAO extends BaseDAO<produit> {
    Connection con;

    public produitDAO() throws SQLException {
        super();
        con = this.getConnection();
    }

    

    @Override
    public void save(produit object) throws SQLException {
        String req = "INSERT INTO produit (nom, prix) VALUES (?, ?);";
            this.preparedStatement = this.connection.prepareStatement(req);
            this.preparedStatement.setString(1 , object.getNom());
            this.preparedStatement.setString(2 , object.getPrix());

            this.preparedStatement.execute();
        }

    @Override
    public boolean update(produit object) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(produit object) throws SQLException {
        return false;
    }

    @Override
    public produit getOne(Long id) throws SQLException {
        return null;
    }

    @Override
    public List<produit> getAll() throws SQLException {

        List<produit> mylist = new ArrayList<produit>();
        String req = " select * from client;" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

            mylist.add( new produit(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3)));
        }

        return mylist;
    }

    @Override
    public Object fetchAll() {
        return null;
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }
}
