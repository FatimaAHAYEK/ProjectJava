package com.product;

import java.sql.SQLException;
import java.util.List;

public class Test1 {
    public static void main(String[] args) {


        try {
            // entity
            produit cli  = new produit(0l,"nahid","9009990099");

            //Transacatio
            produitDAO clidao = new produitDAO();

            // save trasanction
            clidao.save(cli);


            List<produit> mylist =  clidao.getAll();

            for (produit temp :mylist) {

                System.out.println(temp.toString());

            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
}
