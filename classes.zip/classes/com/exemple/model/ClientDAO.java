package com.exemple.model;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClientDAO extends  BaseDAO<Client> {
    Connection con;
    {
        con = null;
    }

    public ClientDAO() throws SQLException {
        super();
    }

    // mapping objet --> relation
    @Override
    public void save(Client object) throws SQLException {

        String req = "insert into client (nom , telephone) values (? , ?) ;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2 , object.getTelepehone());
        this.preparedStatement.execute();
    }
    // function update
    @Override
    public boolean update(Client object) throws SQLException {
        String req = "update client set nom = ?, telephone = ? where id = ?;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1, object.getNom());
        this.preparedStatement.setString(2, object.getTelepehone());
        this.preparedStatement.setLong(3, object.getId_client());
        return this.preparedStatement.execute();
    }
    // function delete
    @Override
    public boolean delete(Client object) throws SQLException {
        String req = "DELETE FROM client WHERE id= ? AND nom = ? AND telephone = ?";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1, object.getId_client());
        this.preparedStatement.setString(2, object.getNom());
        this.preparedStatement.setString(3, object.getTelepehone());
        return this.preparedStatement.execute();
    }
    @Override
    public Client getOne(Long id) throws SQLException {
        return null;
    }
    // mapping relation --> objet
    @Override
    public List<Client> getAll() throws SQLException{

        List<Client> mylist = new ArrayList<Client>();
        String req = " select * from client" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

           mylist.add( new Client(this.resultSet.getLong(1) , this.resultSet.getString(2),
                   this.resultSet.getString(3)));
        }

        return mylist;
    }

    @Override
    public Object fetchAll() {
        return null;
    }

    public Connection getConnection() {
        return connection;
    }


}
