package com.Credite;

public class Credit {
    private Long id_cretite;

    private String nom ;

    private String prix ;

    private String datefin;
    public Credit(){

    }
    public Credit(Long id_cretite , String nom ,String prix  , String datefin ){
        this.id_cretite=id_cretite;
        this.nom=nom;
        this.prix=prix;
        this.datefin=datefin;
    }

    public Long getId_cretite() {
        return id_cretite;
    }

    public void setId_cretite(Long id_cretite) {
        this.id_cretite = id_cretite;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrix() {
        return prix;
    }

    public void setPrix(String prix) {
        this.prix = prix;
    }

    public String getDatefin() {
        return datefin;
    }

    public void setDatefin(String datefin) {
        this.datefin = datefin;
    }

    @Override
    public String toString() {
        return "Credit{" +
                "id_cretite=" + id_cretite +
                ", nom='" + nom + '\'' +
                ", prix='" + prix + '\'' +

                ", datefin='" + datefin + '\'' +
                '}';
    }
}
