package com.Credite;

import com.exemple.model.BaseDAO;
import com.exemple.model.Client;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CreditDAO extends BaseDAO<Credit> {
    Connection con;


    {
        con = null;
    }
    public CreditDAO() throws SQLException {
        super();
    }

    @Override
    public void save(Credit object) throws SQLException {
        String req = "insert into credite ( nom , prix , datefin) values (? , ? , ?) ;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2 , object.getPrix());
        this.preparedStatement.setString(3 , object.getDatefin());
        this.preparedStatement.execute();
    }

    @Override
    public boolean update(Credit object) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(Credit object) throws SQLException {
        String req = "DELETE FROM credite  WHERE id= ? AND nom = ? AND prix = ? AND datefin = ?";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1, object.getId_cretite());
        this.preparedStatement.setString(2, object.getNom());
        this.preparedStatement.setString(3, object.getPrix());
        this.preparedStatement.setString(4, object.getDatefin());
        return this.preparedStatement.execute();
    }

    @Override
    public Credit getOne(Long id) throws SQLException {
        return null;
    }

    @Override
    public List<Credit> getAll() throws SQLException {
        List<Credit> mylist = new ArrayList<Credit>();
        String req = " select * from credite;" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

            mylist.add( new Credit(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3)  , this.resultSet.getString(4)));
        }

        return mylist;
    }
    public Connection getConnection() {
        return connection;
    }
    @Override
    public Object fetchAll() {
        return null;
    }
}
