package com.Commande;

import com.exemple.model.BaseDAO;
import com.exemple.model.Client;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeDAO extends BaseDAO<Commande> {

    Connection con;
    {
        con = null;
    }
    public CommandeDAO() throws SQLException {
        super();
    }

    @Override
    public void save(Commande object) throws SQLException {

        String req = "insert into commande (nom , totale , credite) values (? , ? , ?) ;";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setString(1 , object.getNom());
        this.preparedStatement.setString(2 , object.getTotale());
        this.preparedStatement.setString(3 , object.getCredite());
        this.preparedStatement.execute();

    }

    @Override
    public boolean update(Commande object) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(Commande object) throws SQLException {
        String req = "DELETE FROM commande WHERE id= ? AND nom = ? AND totale = ? AND credite = ? ";
        this.preparedStatement = this.connection.prepareStatement(req);
        this.preparedStatement.setLong(1, object.getId_commande());
        this.preparedStatement.setString(2, object.getNom());
        this.preparedStatement.setString(3, object.getTotale());
        this.preparedStatement.setString(4, object.getCredite());
        return this.preparedStatement.execute();
    }

    @Override
    public Commande getOne(Long id) throws SQLException {
        return null;
    }

    @Override
    public List<Commande> getAll() throws SQLException {
        List<Commande> mylist = new ArrayList<Commande>();
        String req = " select * from commande;" ;

        this.statement = this.connection.createStatement();
        this.resultSet =  this.statement.executeQuery(req);
        while (this.resultSet.next()){

            mylist.add( new Commande(this.resultSet.getLong(1) , this.resultSet.getString(2),
                    this.resultSet.getString(3) ,  this.resultSet.getString(4)));
        }

        return mylist;
    }

    @Override
    public Object fetchAll() {
        return null;
    }
}
