package com.Commande;

public class Commande {
    private Long id_commande;

    private String nom ;

    private String totale ;

    private String credite;
    public Commande() {
    }

    public Commande(Long id_commande, String nom  , String totale , String credite ) {
        this.id_commande=id_commande;
        this.nom=nom;
        this.totale=totale;
        this.credite=credite;
    }

    public Long getId_commande() {
        return id_commande;
    }

    public void setId_commande(Long id_commande) {
        this.id_commande = id_commande;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }


    public String getTotale() {
        return totale;
    }

    public void setTotale(String totale) {
        this.totale = totale;
    }

    public String getCredite() {
        return credite;
    }

    public void setCredite(String credite) {
        this.credite = credite;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "id_commande=" + id_commande +
                ", nom='" + nom + '\'' +
                ", totale='" + totale + '\'' +
                ", credite='" + credite + '\'' +
                '}';
    }
}
