package com.example.esalaf;

import com.exemple.model.Client;
import com.exemple.model.ClientDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import com.Commande.Commande;
import com.Commande.CommandeDAO;

public class commandeController  implements Initializable {
    public Button showCredite;
    @FXML
    private Button showP;


    @FXML
    private TextField nom;

    @FXML
    private TextField To;

    @FXML
    private TextField cre;

    @FXML
    private Button deletf;
    @FXML
    private Button okfatima;
    private  Commande selectedCommande;
    @FXML
    private TableColumn<Commande, Long> idco;
    @FXML
    private TableColumn<Commande, String> nomc;

    @FXML
    private TableColumn<Commande, String> colt;


    @FXML
    private TableColumn<Commande, String> colc;
    @FXML
    private TableView<Commande> mytablfatima;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UpdateTable();
    }

    public void showProduitClick(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("produit.fxml"));
        Stage window = (Stage) showP.getScene().getWindow();
        window.setScene(new Scene(root, 500, 500));
    }

    public void onSvaeClickfatima() {
        Commande cli = new Commande(0l , nom.getText()  , To.getText(), cre.getText() );
        try {
            CommandeDAO clidao = new CommandeDAO();
            clidao.save(cli);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }
    public void UpdateTable(){
        idco.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id_commande"));
        nomc.setCellValueFactory(new PropertyValueFactory<Commande,String>("nom"));
        colt.setCellValueFactory(new PropertyValueFactory<Commande,String>("totale "));
        colc.setCellValueFactory(new PropertyValueFactory<Commande,String>("credite"));
        mytablfatima.setItems(getDataCommande());
    }
    public static ObservableList<Commande> getDataCommande(){
        CommandeDAO clidao = null;
        ObservableList<Commande> listfx = FXCollections.observableArrayList();
        try {
            clidao = new  CommandeDAO();
            for( Commande ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    public void onedeletefatima() {
        Commande selectedCommande =  mytablfatima.getSelectionModel().getSelectedItem();
        if (selectedCommande != null) {
            try {
                CommandeDAO clidao = new CommandeDAO();

                // Créer un dialogue de confirmation
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation de suppression");
                alert.setHeaderText("Voulez-vous vraiment supprimer ce client ?");
                alert.setContentText("Appuyez sur OK pour confirmer.");

                // Afficher le dialogue et attendre la réponse de l'utilisateur
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    clidao.delete(selectedCommande);
                    UpdateTable();

                    // Afficher un message de confirmation
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Opération réussie");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("Le client a été supprimé avec succès !");
                    successAlert.showAndWait();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void onmoseCommande(MouseEvent mouseEvent) {
        Commande selectedCommandet = mytablfatima.getSelectionModel().getSelectedItem();
        if( selectedCommandet != null){
            nom.setText(selectedCommandet.getNom());
            To.setText(selectedCommandet.getTotale());
            cre.setText(selectedCommandet.getCredite());
            okfatima.setDisable(false);
            deletf.setDisable(false);

    }
  }
    private void resetClient (){
        nom.clear();
        To.clear();
        cre.clear();
        selectedCommande = null;
        okfatima.setDisable(false);
        deletf.setDisable(true);
    }


    public void onshowCredite(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Credit.fxml"));
        Stage window = (Stage) showCredite.getScene().getWindow();
        window.setScene(new Scene(root, 530, 500));
    }
}
