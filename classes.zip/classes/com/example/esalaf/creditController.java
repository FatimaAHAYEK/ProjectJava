package com.example.esalaf;
import com.Credite.Credit;
import com.Credite.CreditDAO;
import com.exemple.model.Client;
import com.exemple.model.ClientDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class creditController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UpdateTable();
    }

    @FXML
    private TableColumn<Credit, Long> colid;

    @FXML
    private TableColumn<Credit, String> colnom;
    @FXML
    private TableColumn<Credit, String> colp;

    @FXML
    private Button back;
    @FXML
    private TableColumn<Credit, String> colfin;

    private  Credit selectedCredit;

    @FXML
    private TableView<Credit> mytablecredite;

    @FXML
    private Button cliente;
    @FXML
    private Button deletec;
    @FXML
    private TextField nomC;

    @FXML
    private TextField prix;

    @FXML
    private TextField datef;

    @FXML
    private Button savec;
    @FXML

    public void onsaveclickcredite() {
        Credit cli = new  Credit(0l , nomC.getText() , prix.getText() , datef.getText());
        try {
            CreditDAO clidao = new  CreditDAO();
            clidao.save(cli);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }
    public void UpdateTable(){
        colid.setCellValueFactory(new PropertyValueFactory<Credit,Long>("id_cretite"));
        colnom.setCellValueFactory(new PropertyValueFactory<Credit,String>("nom"));
        colp.setCellValueFactory(new PropertyValueFactory<Credit,String>("prix"));
        colfin.setCellValueFactory(new PropertyValueFactory<Credit,String>("datefin"));
        mytablecredite.setItems(getDataCredit());

    }
    public static ObservableList<Credit> getDataCredit(){
        CreditDAO clidao = null;
        ObservableList<Credit> listfx = FXCollections.observableArrayList();
        try {
            clidao = new CreditDAO();
            for(Credit ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }

    public void onclickdelete() {
        Credit selectedCredit = mytablecredite.getSelectionModel().getSelectedItem();
        if (selectedCredit != null) {
            try {
                CreditDAO clidao = new CreditDAO();

                // Créer un dialogue de confirmation
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation de suppression");
                alert.setHeaderText("Voulez-vous vraiment supprimer ce client ?");
                alert.setContentText("Appuyez sur OK pour confirmer.");

                // Afficher le dialogue et attendre la réponse de l'utilisateur
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    clidao.delete(selectedCredit);
                    UpdateTable();

                    // Afficher un message de confirmation
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Opération réussie");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("Le client a été supprimé avec succès !");
                    successAlert.showAndWait();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

    }
    private void resetCredit(){
        nomC.clear();
        prix.clear();
        datef.clear();
        selectedCredit = null;
        savec.setDisable(false);
        deletec.setDisable(true);
    }

    public void onedeletmosecredit(MouseEvent mouseEvent) {
        selectedCredit = mytablecredite.getSelectionModel().getSelectedItem();
        if(selectedCredit != null){
            nomC.setText(selectedCredit.getNom());
            prix.setText(selectedCredit.getPrix());
            datef.setText(selectedCredit.getDatefin());
            savec.setDisable(false);
            deletec.setDisable(false);

        }
    }

    public void onactionback(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("commande.fxml"));
        Stage window = (Stage) back.getScene().getWindow();
        window.setScene(new Scene(root, 580, 510));
    }

    public void showcliaction(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Stage window = (Stage) cliente.getScene().getWindow();
        window.setScene(new Scene(root, 490, 500));
    }
}
