package com.example.esalaf;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import com.product.produit;
import com.product.produitDAO;

public class produitController  implements Initializable{
    @FXML
    private TextField nom;
    @FXML
    private TextField prix;

    @FXML
    private Button R1;




    @FXML
    private TableColumn<produit, Long> colmid;

    @FXML
    private TableColumn<produit, String> colmnom;

    @FXML
    private TableColumn<produit, String> colmprix;




    @FXML
    private TableView<produit> mytable12;

    @FXML
    private Button delete1;


    @FXML
    private Button ok1;
    @FXML
    private Button Rou;


    @FXML
    void onSaveClick1() {
        produit cli = new produit(0l , nom.getText() ,prix.getText());
        try {
            produitDAO clidao = new produitDAO();
            clidao.save(cli);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }
    public void UpdateTable(){
        colmid.setCellValueFactory(new PropertyValueFactory<produit,Long>("id"));
        colmnom.setCellValueFactory(new PropertyValueFactory<produit,String>("nom"));
        colmprix.setCellValueFactory(new PropertyValueFactory<produit,String>("prix"));

        mytable12.setItems(getDataproduit());
    }
    public static ObservableList<produit> getDataproduit(){
        produitDAO clidao = null;
        ObservableList<produit> listfx = FXCollections.observableArrayList();
        try {
            clidao = new produitDAO();
            for(produit ettemp : clidao.getAll())
                listfx.add(ettemp);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }


    @FXML
    void ondeleteClick1(ActionEvent event) {

    }
    public void onemoseClick1(javafx.scene.input.MouseEvent mouseEvent) {

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }
    public void onRouClick1(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Stage window = (Stage) Rou.getScene().getWindow();
        window.setScene(new Scene(root, 600, 500));

    }

    public void Click1(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("commande.fxml"));
        Stage window = (Stage) R1.getScene().getWindow();
        window.setScene(new Scene(root, 580,510));

    }
}
