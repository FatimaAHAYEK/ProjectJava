package com.example.esalaf;

import com.exemple.model.Client;
import com.exemple.model.ClientDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    Connection con = null;
    private ClientDAO clientDAO;
    @FXML
    private TextField nom;

    @FXML
    private TextField tele;
    //----------------------------------
    @FXML
    private Button ok;

    @FXML
    private Button delete;
    @FXML
    private Button show;


    @FXML
    private Button update;
    private  Client selectedclient;
   //-----------------------------------
    @FXML
    private TableView<Client> mytab;

    @FXML
    private TableColumn<Client, Long> col_id;

    @FXML
    private TableColumn<Client, String> col_nom;

    @FXML
    private TableColumn<Client, String> col_tele;
    private Object object;

    //-------------------------------------------------------------------------------------------
    //saveClient
    @FXML
    protected void onSaveButtonClick(){
        Client cli = new Client(0l , nom.getText() , tele.getText());
        try {
            ClientDAO clidao = new ClientDAO();
            clidao.save(cli);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        UpdateTable();
    }
    //pour view de client dans la table
    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Client,Long>("id_client"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Client,String>("nom"));
        col_tele.setCellValueFactory(new PropertyValueFactory<Client,String>("telepehone"));
        mytab.setItems(getDataClients());
    }

    public static ObservableList<Client> getDataClients(){
        ClientDAO clidao = null;
        ObservableList<Client> listfx = FXCollections.observableArrayList();
        try {
            clidao = new ClientDAO();
            for(Client ettemp : clidao.getAll())
                listfx.add(ettemp);

       } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return listfx ;
    }
    //-------------------------------------------------------------------------------------
   //update
    @FXML
    void onUpdateButtonClick() {
        Client selectedclient = mytab.getSelectionModel().getSelectedItem();
        if(selectedclient != null){
            try {
                ClientDAO clidao = new ClientDAO();
                selectedclient.setNom(nom.getText());
                selectedclient.setTelepehone(tele.getText());
                clidao.update(selectedclient);
                UpdateTable();

                // Créer un dialogue de confirmation
                Dialog<String> dialog = new Dialog<>();
                dialog.setTitle("Confirmation");
                dialog.setHeaderText(null);
                dialog.setContentText("Le client a été mis à jour avec succès !");

                // Ajouter un bouton "OK" et le lier à la fermeture du dialogue
                ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
                dialog.getDialogPane().getButtonTypes().add(okButton);
                dialog.setResultConverter(dialogButton -> {
                    if (dialogButton == okButton) {
                        return "OK";
                    }
                    return null;
                });

                // Afficher le dialogue et attendre la réponse de l'utilisateur
                Optional<String> result = dialog.showAndWait();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
//------------------------------------------------------------------------------------
   //delete
    @FXML
    void onDeleteButtonClick() {
        Client selectedClient = mytab.getSelectionModel().getSelectedItem();
        if (selectedClient != null) {
            try {
                ClientDAO clidao = new ClientDAO();

                // Créer un dialogue de confirmation
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation de suppression");
                alert.setHeaderText("Voulez-vous vraiment supprimer ce client ?");
                alert.setContentText("Appuyez sur OK pour confirmer.");

                // Afficher le dialogue et attendre la réponse de l'utilisateur
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    clidao.delete(selectedClient);
                    UpdateTable();

                    // Afficher un message de confirmation
                    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                    successAlert.setTitle("Opération réussie");
                    successAlert.setHeaderText(null);
                    successAlert.setContentText("Le client a été supprimé avec succès !");
                    successAlert.showAndWait();
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        }
        //-----------------------------------------------------------------
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();

    }
//----------------------------------------------------------------------------
    // pour selectioner un client table
    public void tableclientClicked(MouseEvent mouseEvent) {
        selectedclient = mytab.getSelectionModel().getSelectedItem();
        if( selectedclient != null){
            nom.setText(selectedclient.getNom());
            tele.setText(selectedclient.getTelepehone());
            ok.setDisable(false);
            update.setDisable(false);
            delete.setDisable(false);
        }


    }
    // pour les button
    private void resetClient (){
        nom.clear();
        tele.clear();
        selectedclient = null;
        ok.setDisable(false);
        update.setDisable(true);
        delete.setDisable(true);
    }


    public void onshowClick() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("commande.fxml"));
        Stage window = (Stage) show.getScene().getWindow();
        window.setScene(new Scene(root, 580, 500));
    }
}